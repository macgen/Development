//
//  Projects.h
//  CollaB
//
//  Created by James J. Kim on 2/17/15.
//  Copyright (c) 2015 James J. Kim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Projects : NSObject

//Properties to hold Project Information
@property NSString *projectName;
@property NSDate *createdDate;
@property NSDate *dueDate;
@end
