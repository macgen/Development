//
//  AppDelegate.h
//  ProjectX
//
//  Created by James Kim on 12/13/15.
//  Copyright © 2015 James J. Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

