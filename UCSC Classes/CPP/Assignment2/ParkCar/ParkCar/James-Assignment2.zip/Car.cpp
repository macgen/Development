//
//  Car.cpp
//  ParkCar
//
//  Created by James Kim on 10/9/15.
//  Copyright © 2015 James J. Kim. All rights reserved.
//

#include <stdio.h>

class Car
{
    public:
        Car(int tNumber, Car *nextCar); //default constructor
        Car();
    
    //what's the next car ?
    //What's the car before me ?
    
    void setLinkToNextCar(Car *car);
    Car* getLinkToNextCar();
    
    void setAssignedTicketNumber(int tNumber);
    int getAssignedTicketNumber();
    
    
        
    private:
        unsigned int assignedTicketNumber;
        Car *linkToTheCarParkedBehind;
};

Car::Car(): assignedTicketNumber(0), linkToTheCarParkedBehind(0)
{
    assignedTicketNumber = 0;
    linkToTheCarParkedBehind = 0;
}

//Car::Car(int tNumber, Car *nextCar): assignedTicketNumber(tNumber), linkToTheCarParkedBehind(nextCar)
//{
//    assignedTicketNumber = tNumber;
//    linkToTheCarParkedBehind = nextCar;
//}


void Car::setAssignedTicketNumber(int tNumber)
{
    assignedTicketNumber = tNumber;
}

int Car::getAssignedTicketNumber()
{
    return assignedTicketNumber;
}


void Car::setLinkToNextCar(Car *car)
{
    linkToTheCarParkedBehind = car;
}

Car* Car::getLinkToNextCar()
{
    return linkToTheCarParkedBehind;
}
